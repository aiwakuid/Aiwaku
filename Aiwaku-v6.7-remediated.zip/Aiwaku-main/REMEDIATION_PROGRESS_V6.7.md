# AIWAKU V6.7 Remediation Progress

## Implemented in this pass

- P0-01: inbound WhatsApp dedupe is database-backed with a unique `(tenant_id, provider_message_id)` partial index.
- P0-02: active conversation get/create is serialized by the existing partial unique index through `bot_get_or_create_wa_conversation`.
- P0-03: inbound messages now have durable `received/processing/processed/failed` state, attempts, lease timestamps, and retry semantics.
- P0-04: conversation processing is claimed with a lease so concurrent messages for the same conversation are retried rather than processed concurrently.
- P0-05: `bot_create_order_atomic` now locks and validates the exact tenant/customer/conversation tuple.
- P0-06: `orders.wa_conversation_id` records the exact originating WhatsApp conversation.
- P0-13 partial remediation: automated processing errors now move the conversation to explicit `handoff_human` step.

## Verification

The repository was unpacked from `Aiwaku-main (7).zip`. The existing Node dependency install could not complete within the review environment timeout, so full `typecheck`, test, and build verification remains pending. The previous audit also states that CI/build/typecheck/integration evidence was not yet a PASS.

## Next pass

1. P0-07/P0-10: payment reservation recovery and order/payment recovery state machine.
2. P0-08: deterministic Midtrans provider order ID and reconciliation.
3. P0-09: central strict payment/order transitions.
4. P0-11/P0-12: executable booking/service/membership/hybrid flow or explicit feature gating.
5. P0-14/P0-15: DEMO_MODE isolation and canonical schema/release cleanup.
