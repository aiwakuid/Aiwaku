-- AIWAKU V6.7 — Durable WhatsApp inbox + conversation claim
-- Review remediation: P0-01 .. P0-06
--
-- This migration makes inbound delivery durable and retryable, removes
-- check-before-insert dedupe races, makes active conversation creation
-- atomic, and records the exact originating conversation on an order.

-- ------------------------------------------------------------
-- 1) Durable inbox state
-- ------------------------------------------------------------
alter table public.wa_conversations
  add column if not exists processing_message_id uuid,
  add column if not exists processing_started_at timestamptz;

alter table public.wa_messages
  add column if not exists processing_status text not null default 'received'
    check (processing_status in ('received','processing','processed','failed')),
  add column if not exists processing_started_at timestamptz,
  add column if not exists processed_at timestamptz,
  add column if not exists processing_attempts integer not null default 0,
  add column if not exists processing_error text;

create unique index if not exists wa_messages_provider_unique_idx
  on public.wa_messages(tenant_id, provider_message_id)
  where provider_message_id is not null and direction = 'inbound';

create index if not exists wa_messages_processing_idx
  on public.wa_messages(processing_status, processing_started_at)
  where direction = 'inbound';

-- ------------------------------------------------------------
-- 2) Exact order -> originating WA conversation correlation
-- ------------------------------------------------------------
alter table public.orders
  add column if not exists wa_conversation_id uuid references public.wa_conversations(id) on delete set null;

create index if not exists orders_wa_conversation_idx
  on public.orders(wa_conversation_id)
  where wa_conversation_id is not null;

-- ------------------------------------------------------------
-- 3) Atomic active conversation get/create.
--    The partial unique index on (tenant_id, customer_wa) where active
--    is the serialization boundary. The function returns the existing
--    row on a concurrent insert instead of treating unique_violation as
--    successful delivery.
-- ------------------------------------------------------------
create or replace function public.bot_get_or_create_wa_conversation(
  p_tenant_id uuid,
  p_customer_wa text,
  p_flow_type text
)
returns public.wa_conversations
language plpgsql
security definer
set search_path = public
as $$
declare
  v_conversation public.wa_conversations;
begin
  if p_tenant_id is null or p_customer_wa is null or trim(p_customer_wa) = '' then
    raise exception 'Tenant/customer WhatsApp wajib diisi';
  end if;

  if p_flow_type not in ('order','booking','service','membership','hybrid') then
    raise exception 'Flow type tidak valid';
  end if;

  insert into public.wa_conversations (
    tenant_id, customer_wa, flow_type, current_step, context, status, last_message_at
  ) values (
    p_tenant_id, trim(p_customer_wa), p_flow_type, 'greeting', '{}'::jsonb, 'active', now()
  )
  on conflict (tenant_id, customer_wa) where status = 'active'
  do update set last_message_at = public.wa_conversations.last_message_at
  returning * into v_conversation;

  return v_conversation;
end;
$$;

revoke all on function public.bot_get_or_create_wa_conversation(uuid,text,text) from public;
grant execute on function public.bot_get_or_create_wa_conversation(uuid,text,text) to service_role;

-- ------------------------------------------------------------
-- 4) Claim one inbound message for processing.
--    A failed message can be retried. A processing message is reclaimable
--    only after the lease expires, preventing two workers from processing
--    the same conversation concurrently during the normal path.
-- ------------------------------------------------------------
create or replace function public.bot_claim_wa_message(
  p_message_id uuid,
  p_lease_seconds integer default 120
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_message public.wa_messages;
  v_conversation public.wa_conversations;
  v_lease interval := make_interval(secs => greatest(30, least(p_lease_seconds, 900)));
begin
  select * into v_message
  from public.wa_messages
  where id = p_message_id and direction = 'inbound'
  for update;

  if not found then
    return jsonb_build_object('claimed', false, 'reason', 'not_found');
  end if;

  if v_message.processing_status = 'processed' then
    return jsonb_build_object('claimed', false, 'reason', 'processed');
  end if;

  if v_message.processing_status = 'processing'
     and v_message.processing_started_at > now() - v_lease then
    return jsonb_build_object('claimed', false, 'reason', 'message_processing');
  end if;

  select * into v_conversation
  from public.wa_conversations
  where id = v_message.conversation_id
  for update;

  if not found then
    update public.wa_messages
      set processing_status = 'failed',
          processing_error = 'Conversation tidak ditemukan',
          processing_attempts = processing_attempts + 1
    where id = v_message.id;
    return jsonb_build_object('claimed', false, 'reason', 'conversation_not_found');
  end if;

  if v_conversation.status = 'handoff_human' then
    update public.wa_messages
      set processing_status = 'processed', processed_at = now(), processing_error = null,
          processing_started_at = null, processing_attempts = processing_attempts + 1
    where id = v_message.id;
    return jsonb_build_object('claimed', false, 'reason', 'handoff_human');
  end if;

  if v_conversation.processing_message_id is not null
     and v_conversation.processing_message_id <> v_message.id
     and v_conversation.processing_started_at > now() - v_lease then
    return jsonb_build_object('claimed', false, 'reason', 'conversation_processing');
  end if;

  update public.wa_messages
    set processing_status = 'processing',
        processing_started_at = now(),
        processing_attempts = processing_attempts + 1,
        processing_error = null
  where id = v_message.id;

  update public.wa_conversations
    set processing_message_id = v_message.id,
        processing_started_at = now()
  where id = v_conversation.id;

  return jsonb_build_object(
    'claimed', true,
    'message_id', v_message.id,
    'conversation_id', v_conversation.id
  );
end;
$$;

revoke all on function public.bot_claim_wa_message(uuid,integer) from public;
grant execute on function public.bot_claim_wa_message(uuid,integer) to service_role;

create or replace function public.bot_finish_wa_message(
  p_message_id uuid,
  p_status text,
  p_error text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_status not in ('processed','failed') then
    raise exception 'Status inbox tidak valid';
  end if;

  update public.wa_messages
  set processing_status = p_status,
      processing_error = p_error,
      processed_at = case when p_status = 'processed' then now() else null end,
      processing_started_at = null
  where id = p_message_id and direction = 'inbound';

  update public.wa_conversations
  set processing_message_id = null,
      processing_started_at = null
  where processing_message_id = p_message_id;
end;
$$;

revoke all on function public.bot_finish_wa_message(uuid,text,text) from public;
grant execute on function public.bot_finish_wa_message(uuid,text,text) to service_role;

-- ------------------------------------------------------------
-- 5) Harden bot_create_order_atomic conversation ownership and persist
--    the exact originating conversation on the order.
-- ------------------------------------------------------------
create or replace function public.bot_create_order_atomic(
  p_tenant_id uuid,
  p_customer_wa text,
  p_customer_name text,
  p_items jsonb,
  p_conversation_id uuid,
  p_idempotency_key text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_item jsonb;
  v_menu record;
  v_conversation public.wa_conversations;
  v_qty integer;
  v_subtotal bigint := 0;
  v_total bigint;
  v_order_id uuid := gen_random_uuid();
  v_invoice text;
  v_existing jsonb;
  v_normalized jsonb := '[]'::jsonb;
  v_key text := coalesce(p_idempotency_key, p_conversation_id::text);
begin
  if p_items is null or jsonb_array_length(p_items) = 0 then
    raise exception 'Order kosong';
  end if;

  select * into v_conversation
  from public.wa_conversations
  where id = p_conversation_id
    and tenant_id = p_tenant_id
    and customer_wa = p_customer_wa
  for update;

  if not found then
    raise exception 'Conversation WhatsApp tidak valid';
  end if;

  select to_jsonb(o) into v_existing
  from public.orders o
  where o.tenant_id = p_tenant_id and o.idempotency_key = v_key
  limit 1;
  if v_existing is not null then
    return v_existing;
  end if;

  for v_item in
    select value from jsonb_array_elements(p_items)
    order by coalesce(value->>'menu_id', value->>'menuId')
  loop
    v_qty := floor(coalesce((v_item->>'qty')::numeric, 0));
    if v_qty <= 0 then raise exception 'Quantity tidak valid'; end if;

    select id, name, price, stock, is_active into v_menu
    from public.menus
    where id = (v_item->>'menu_id')::uuid and tenant_id = p_tenant_id
    for update;

    if not found then raise exception 'Produk tidak ditemukan'; end if;
    if not v_menu.is_active then raise exception 'Produk tidak aktif: %', v_menu.name; end if;
    if v_menu.stock < v_qty then raise exception 'Stok % tidak cukup', v_menu.name; end if;

    v_subtotal := v_subtotal + (v_menu.price::bigint * v_qty);
    v_normalized := v_normalized || jsonb_build_object(
      'menu_id', v_menu.id, 'name', v_menu.name, 'qty', v_qty,
      'price', v_menu.price, 'subtotal', v_menu.price::bigint * v_qty
    );
    update public.menus set stock = stock - v_qty where id = v_menu.id;
  end loop;

  v_total := v_subtotal;
  v_invoice := 'WA-' || to_char(now(), 'YYYYMMDD') || '-' || substr(v_order_id::text, 1, 6);

  insert into public.orders (
    id, tenant_id, invoice_no, customer_name, customer_wa, items,
    subtotal, discount, tax, total, dp, remaining, status, idempotency_key,
    wa_conversation_id, created_at
  ) values (
    v_order_id, p_tenant_id, v_invoice, coalesce(p_customer_name, p_customer_wa), p_customer_wa, v_normalized,
    v_subtotal, 0, 0, v_total, 0, v_total, 'pending', v_key,
    p_conversation_id, now()
  );

  update public.wa_conversations
    set context = context || jsonb_build_object('order_id', v_order_id)
  where id = p_conversation_id;

  select to_jsonb(o) into v_existing from public.orders o where o.id = v_order_id;
  return v_existing;
end;
$$;

revoke all on function public.bot_create_order_atomic(uuid,text,text,jsonb,uuid,text) from public;
grant execute on function public.bot_create_order_atomic(uuid,text,text,jsonb,uuid,text) to service_role;
